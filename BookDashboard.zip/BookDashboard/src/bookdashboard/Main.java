package bookdashboard;

import java.sql.SQLException;
import bookdashboard.frames.HomeFrame;

public class Main {
    
    public static void main(String[] args) throws SQLException {
        new HomeFrame().setVisible(true);
    }
}
