package bookdashboard.frames;

import java.awt.CardLayout;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import bookdashboard.databases.KoneksiDatabase;
import java.awt.event.ActionListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class HomeFrame extends javax.swing.JFrame {
    
    private final Connection conn;
    
    private final CardLayout containerLayout;
    private final DefaultTableModel tabelModelBuku;

    /**
     * Creates new form HomeFrame
     */
    public HomeFrame() {
        //Database
        conn = new KoneksiDatabase().getKoneksi();
        
        initComponents();
        
        // Init side bar button
        sidebarButton();
        
        // Init side bar
        containerLayout = (CardLayout) panelContainer.getLayout();
        containerLayout.show(panelContainer, "panelHome");
        sideBarMenu();
        
        //Tabel model
        tabelModelBuku = (DefaultTableModel) tabel_buku.getModel();
        tabel_buku.setModel(tabelModelBuku);
        loadDataBuku();
        
        getJumlahBuku();
        
        // Live search
        tf_keyword_buku.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent arg0) {
                String keyword = tf_keyword_buku.getText();
                cariBuku(keyword);
            }

            @Override
            public void removeUpdate(DocumentEvent arg0) {
                String keyword = tf_keyword_buku.getText();
                cariBuku(keyword);
            }

            @Override
            public void changedUpdate(DocumentEvent arg0) {
                String keyword = tf_keyword_buku.getText();
                cariBuku(keyword);
            }
        });
        
        btn_show_modal.addActionListener((ActionListener) -> {
            dialogTest.setVisible(true);
        });
    }

    private void sidebarButton() {
        btnSidebarHome.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent arg0) {}

            @Override
            public void mousePressed(MouseEvent arg0) {}

            @Override
            public void mouseReleased(MouseEvent arg0) {}

            @Override
            public void mouseEntered(MouseEvent arg0) {
                btnSidebarHome.setBackground(new java.awt.Color(41, 217, 213));
            }

            @Override
            public void mouseExited(MouseEvent arg0) {
                btnSidebarHome.setBackground(new java.awt.Color(18, 18, 20));
            }
        });
        
        btnSidebarMasterBuku.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent arg0) {}

            @Override
            public void mousePressed(MouseEvent arg0) {}

            @Override
            public void mouseReleased(MouseEvent arg0) {}

            @Override
            public void mouseEntered(MouseEvent arg0) {
                btnSidebarMasterBuku.setBackground(new java.awt.Color(41, 217, 213));
            }

            @Override
            public void mouseExited(MouseEvent arg0) {
                btnSidebarMasterBuku.setBackground(new java.awt.Color(18, 18, 20));
            }
        });
    }
    
    private void sideBarMenu() {
        btnSidebarHome.addActionListener((ActionEvent ae) -> {
            containerLayout.show(panelContainer, "panelHome");
        });
        
        btnSidebarMasterBuku.addActionListener((ActionEvent ae) -> {
            containerLayout.show(panelContainer, "panelMasterBuku");
        });
    }

    private void loadDataBuku() {
        String sql = "SELECT * FROM v_list_buku;";
        
        try (Statement st = conn.createStatement();) {
            
            ResultSet result = st.executeQuery(sql);
            
            // Tampilkan hasil ke tabel
            while (result.next()) {                
                String[] data = new String[5];
                data[0] = result.getString("kode_buku");
                data[1] = result.getString("judul");
                data[2] = result.getString("nama_penerbit");
                data[3] = result.getString("harga");
                data[4] = result.getString("stok");
                
                tabelModelBuku.addRow(data);
            }
            
            st.close();
        } catch (SQLException e) {
            System.err.println("Lokasi : " + getClass().getName());
            System.err.println(e.getErrorCode() + " : " + e.getMessage());
        }
    }
    
    private void cariBuku(String keyword) {
        tabelModelBuku.setRowCount(0);
        
        String sql = 
                "SELECT buku.`kode_buku`,buku.`judul`,penerbit.`nama_penerbit`,buku.`harga`,buku.`stok` " + 
                " FROM buku " +
                " INNER JOIN penerbit ON penerbit.`id_penerbit` = buku.`id_penerbit` " +
                " INNER JOIN kategori ON kategori.`id_kategori` = buku.`id_kategori` "
                + "WHERE buku.judul LIKE '%"+ keyword +"%' "
                + "OR penerbit.nama_penerbit LIKE '%"+ keyword +"%';";
        
        try (Statement st = conn.createStatement();) {
            
            ResultSet result = st.executeQuery(sql);
            
            // Tampilkan hasil ke tabel
            while (result.next()) {                
                String[] data = new String[5];
                data[0] = result.getString("kode_buku");
                data[1] = result.getString("judul");
                data[2] = result.getString("nama_penerbit");
                data[3] = result.getString("harga");
                data[4] = result.getString("stok");
                
                tabelModelBuku.addRow(data);
            }
            
            st.close();
        } catch (SQLException e) {
            System.err.println("Lokasi : " + getClass().getName());
            System.err.println(e.getErrorCode() + " : " + e.getMessage());
        }
    }
    
    private void getJumlahBuku() {
        String sql = "SELECT fn_get_jumlah_buku() AS jumlah_buku;";
        
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {                
                label_jumlah_buku.setText(rs.getString("jumlah_buku"));
            }
        } catch (SQLException e) {
            System.err.println("Lokasi : " + getClass().getName());
            System.err.println(e.getErrorCode() + " : " + e.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dialogTambahBuku = new javax.swing.JDialog();
        jLabel4 = new javax.swing.JLabel();
        tf_kode_buku = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        tf_judul = new javax.swing.JTextField();
        tf_penulis = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        cb_penerbit = new javax.swing.JComboBox<>();
        cb_kategori = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        tf_tahun = new javax.swing.JTextField();
        tf_harga = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        tf_stok = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        btn_tambah = new javax.swing.JButton();
        dialogTest = new javax.swing.JDialog();
        jLabel13 = new javax.swing.JLabel();
        panelBackground = new javax.swing.JPanel();
        splitPaneHome = new javax.swing.JSplitPane();
        panelSidebar = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnSidebarHome = new javax.swing.JButton();
        btnSidebarMasterBuku = new javax.swing.JButton();
        panelContainer = new javax.swing.JPanel();
        panelHome = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        label_jumlah_buku = new javax.swing.JLabel();
        btn_show_modal = new javax.swing.JButton();
        panelMasterBuku = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btn_tambah_buku = new javax.swing.JButton();
        btn_cari_buku = new javax.swing.JButton();
        tf_keyword_buku = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel_buku = new javax.swing.JTable();

        dialogTambahBuku.setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        dialogTambahBuku.setTitle("Form Tambah Buku");
        dialogTambahBuku.setBackground(new java.awt.Color(255, 255, 255));
        dialogTambahBuku.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        dialogTambahBuku.setLocation(new java.awt.Point(0, 0));
        dialogTambahBuku.setMinimumSize(new java.awt.Dimension(400, 600));
        dialogTambahBuku.setModal(true);
        dialogTambahBuku.setModalExclusionType(java.awt.Dialog.ModalExclusionType.APPLICATION_EXCLUDE);
        dialogTambahBuku.setName("dialogTambahBuku"); // NOI18N
        dialogTambahBuku.setPreferredSize(new java.awt.Dimension(400, 600));
        dialogTambahBuku.setResizable(false);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel4.setText("Kode Buku");
        jLabel4.setMaximumSize(new java.awt.Dimension(57, 24));
        jLabel4.setMinimumSize(new java.awt.Dimension(57, 24));
        jLabel4.setPreferredSize(new java.awt.Dimension(57, 24));

        tf_kode_buku.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        tf_kode_buku.setMinimumSize(new java.awt.Dimension(7, 24));
        tf_kode_buku.setPreferredSize(new java.awt.Dimension(7, 24));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel6.setText("Judul");
        jLabel6.setMaximumSize(new java.awt.Dimension(57, 24));
        jLabel6.setMinimumSize(new java.awt.Dimension(57, 24));
        jLabel6.setPreferredSize(new java.awt.Dimension(57, 24));

        tf_judul.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        tf_judul.setMinimumSize(new java.awt.Dimension(7, 24));
        tf_judul.setPreferredSize(new java.awt.Dimension(7, 24));

        tf_penulis.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        tf_penulis.setMinimumSize(new java.awt.Dimension(7, 24));
        tf_penulis.setPreferredSize(new java.awt.Dimension(7, 24));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel7.setText("Penulis");
        jLabel7.setMaximumSize(new java.awt.Dimension(57, 24));
        jLabel7.setMinimumSize(new java.awt.Dimension(57, 24));
        jLabel7.setPreferredSize(new java.awt.Dimension(57, 24));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel8.setText("Penerbit");
        jLabel8.setMaximumSize(new java.awt.Dimension(57, 24));
        jLabel8.setMinimumSize(new java.awt.Dimension(57, 24));
        jLabel8.setPreferredSize(new java.awt.Dimension(57, 24));

        cb_penerbit.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Gama Media", "Penerbit Anda", "Penerbit Informasi", "Meditek Publishion", "Media Informatika", "Airlangga" }));
        cb_penerbit.setMinimumSize(new java.awt.Dimension(55, 24));
        cb_penerbit.setPreferredSize(new java.awt.Dimension(55, 24));

        cb_kategori.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pemrograman", "Sains", "Kesehatan", "Hibura", "Novel", "Religi" }));
        cb_kategori.setMinimumSize(new java.awt.Dimension(55, 24));
        cb_kategori.setPreferredSize(new java.awt.Dimension(55, 24));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel9.setText("Kategori");
        jLabel9.setMaximumSize(new java.awt.Dimension(57, 24));
        jLabel9.setMinimumSize(new java.awt.Dimension(57, 24));
        jLabel9.setPreferredSize(new java.awt.Dimension(57, 24));

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel10.setText("Tahun");
        jLabel10.setMaximumSize(new java.awt.Dimension(57, 24));
        jLabel10.setMinimumSize(new java.awt.Dimension(57, 24));
        jLabel10.setPreferredSize(new java.awt.Dimension(57, 24));

        tf_tahun.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        tf_tahun.setMinimumSize(new java.awt.Dimension(7, 24));
        tf_tahun.setPreferredSize(new java.awt.Dimension(7, 24));

        tf_harga.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        tf_harga.setMinimumSize(new java.awt.Dimension(7, 24));
        tf_harga.setPreferredSize(new java.awt.Dimension(7, 24));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel11.setText("Harga");
        jLabel11.setMaximumSize(new java.awt.Dimension(57, 24));
        jLabel11.setMinimumSize(new java.awt.Dimension(57, 24));
        jLabel11.setPreferredSize(new java.awt.Dimension(57, 24));

        tf_stok.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        tf_stok.setMinimumSize(new java.awt.Dimension(7, 24));
        tf_stok.setPreferredSize(new java.awt.Dimension(7, 24));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel12.setText("Stok");
        jLabel12.setMaximumSize(new java.awt.Dimension(57, 24));
        jLabel12.setMinimumSize(new java.awt.Dimension(57, 24));
        jLabel12.setPreferredSize(new java.awt.Dimension(57, 24));

        btn_tambah.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        btn_tambah.setText("Tambah");
        btn_tambah.setMaximumSize(new java.awt.Dimension(100, 24));
        btn_tambah.setMinimumSize(new java.awt.Dimension(100, 24));
        btn_tambah.setPreferredSize(new java.awt.Dimension(100, 24));

        javax.swing.GroupLayout dialogTambahBukuLayout = new javax.swing.GroupLayout(dialogTambahBuku.getContentPane());
        dialogTambahBuku.getContentPane().setLayout(dialogTambahBukuLayout);
        dialogTambahBukuLayout.setHorizontalGroup(
            dialogTambahBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogTambahBukuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(dialogTambahBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tf_kode_buku, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tf_judul, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tf_penulis, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cb_penerbit, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cb_kategori, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tf_tahun, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tf_harga, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tf_stok, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(dialogTambahBukuLayout.createSequentialGroup()
                        .addGroup(dialogTambahBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_tambah, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 252, Short.MAX_VALUE)))
                .addContainerGap())
        );
        dialogTambahBukuLayout.setVerticalGroup(
            dialogTambahBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogTambahBukuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf_kode_buku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf_judul, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf_penulis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cb_penerbit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cb_kategori, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf_tahun, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf_harga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tf_stok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_tambah, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(74, Short.MAX_VALUE))
        );

        dialogTambahBuku.getAccessibleContext().setAccessibleParent(null);

        dialogTest.setTitle("Modal Test");
        dialogTest.setMinimumSize(new java.awt.Dimension(400, 300));
        dialogTest.setModal(true);

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel13.setText("Modal");

        javax.swing.GroupLayout dialogTestLayout = new javax.swing.GroupLayout(dialogTest.getContentPane());
        dialogTest.getContentPane().setLayout(dialogTestLayout);
        dialogTestLayout.setHorizontalGroup(
            dialogTestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogTestLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, 380, Short.MAX_VALUE)
                .addContainerGap())
        );
        dialogTestLayout.setVerticalGroup(
            dialogTestLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogTestLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addContainerGap(272, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Toko Buku");
        setMinimumSize(new java.awt.Dimension(900, 600));

        panelBackground.setBackground(new java.awt.Color(255, 255, 255));

        splitPaneHome.setBorder(null);
        splitPaneHome.setDividerLocation(200);
        splitPaneHome.setDividerSize(0);
        splitPaneHome.setLastDividerLocation(200);
        splitPaneHome.setMinimumSize(new java.awt.Dimension(900, 600));
        splitPaneHome.setPreferredSize(new java.awt.Dimension(900, 600));

        panelSidebar.setBackground(new java.awt.Color(18, 18, 20));
        panelSidebar.setMinimumSize(new java.awt.Dimension(200, 600));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(41, 217, 213));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("T-Buku");

        btnSidebarHome.setBackground(new java.awt.Color(18, 18, 20));
        btnSidebarHome.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnSidebarHome.setForeground(new java.awt.Color(86, 105, 155));
        btnSidebarHome.setText("Dashboard");
        btnSidebarHome.setBorder(null);
        btnSidebarHome.setFocusable(false);
        btnSidebarHome.setIconTextGap(8);
        btnSidebarHome.setMargin(new java.awt.Insets(2, 16, 2, 16));
        btnSidebarHome.setMaximumSize(new java.awt.Dimension(200, 48));
        btnSidebarHome.setMinimumSize(new java.awt.Dimension(200, 48));
        btnSidebarHome.setPreferredSize(new java.awt.Dimension(200, 48));

        btnSidebarMasterBuku.setBackground(new java.awt.Color(18, 18, 20));
        btnSidebarMasterBuku.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnSidebarMasterBuku.setForeground(new java.awt.Color(86, 105, 155));
        btnSidebarMasterBuku.setText("Master Buku");
        btnSidebarMasterBuku.setBorder(null);
        btnSidebarMasterBuku.setFocusPainted(false);
        btnSidebarMasterBuku.setFocusable(false);
        btnSidebarMasterBuku.setIconTextGap(8);
        btnSidebarMasterBuku.setMaximumSize(new java.awt.Dimension(200, 48));
        btnSidebarMasterBuku.setMinimumSize(new java.awt.Dimension(200, 48));
        btnSidebarMasterBuku.setPreferredSize(new java.awt.Dimension(200, 48));

        javax.swing.GroupLayout panelSidebarLayout = new javax.swing.GroupLayout(panelSidebar);
        panelSidebar.setLayout(panelSidebarLayout);
        panelSidebarLayout.setHorizontalGroup(
            panelSidebarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnSidebarHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(btnSidebarMasterBuku, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panelSidebarLayout.setVerticalGroup(
            panelSidebarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSidebarLayout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSidebarHome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(btnSidebarMasterBuku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 434, Short.MAX_VALUE))
        );

        splitPaneHome.setLeftComponent(panelSidebar);

        panelContainer.setBackground(new java.awt.Color(255, 255, 255));
        panelContainer.setMinimumSize(new java.awt.Dimension(700, 600));
        panelContainer.setLayout(new java.awt.CardLayout());

        panelHome.setBackground(new java.awt.Color(242, 255, 252));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(47, 61, 99));
        jLabel3.setText("Dashboard");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        jLabel5.setText("Jumlah Buku");

        label_jumlah_buku.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        label_jumlah_buku.setText("0");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 101, Short.MAX_VALUE)
                .addComponent(label_jumlah_buku)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(label_jumlah_buku, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        btn_show_modal.setText("modal");

        javax.swing.GroupLayout panelHomeLayout = new javax.swing.GroupLayout(panelHome);
        panelHome.setLayout(panelHomeLayout);
        panelHomeLayout.setHorizontalGroup(
            panelHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelHomeLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_show_modal, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(490, Short.MAX_VALUE))
        );
        panelHomeLayout.setVerticalGroup(
            panelHomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelHomeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_show_modal)
                .addContainerGap())
        );

        panelContainer.add(panelHome, "panelHome");

        panelMasterBuku.setBackground(new java.awt.Color(242, 255, 252));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(47, 61, 99));
        jLabel2.setText("Data Buku");
        jLabel2.setMaximumSize(new java.awt.Dimension(65, 32));
        jLabel2.setMinimumSize(new java.awt.Dimension(65, 32));
        jLabel2.setPreferredSize(new java.awt.Dimension(65, 32));

        btn_tambah_buku.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btn_tambah_buku.setText("Tambah Buku");
        btn_tambah_buku.setFocusPainted(false);
        btn_tambah_buku.setMaximumSize(new java.awt.Dimension(200, 24));
        btn_tambah_buku.setMinimumSize(new java.awt.Dimension(128, 24));
        btn_tambah_buku.setPreferredSize(new java.awt.Dimension(128, 24));
        btn_tambah_buku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambah_bukuActionPerformed(evt);
            }
        });

        btn_cari_buku.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btn_cari_buku.setText("Cari");
        btn_cari_buku.setFocusPainted(false);
        btn_cari_buku.setMaximumSize(new java.awt.Dimension(72, 24));
        btn_cari_buku.setMinimumSize(new java.awt.Dimension(72, 24));
        btn_cari_buku.setPreferredSize(new java.awt.Dimension(72, 24));
        btn_cari_buku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cari_bukuActionPerformed(evt);
            }
        });

        tf_keyword_buku.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        tf_keyword_buku.setForeground(new java.awt.Color(47, 61, 99));
        tf_keyword_buku.setMaximumSize(new java.awt.Dimension(128, 24));
        tf_keyword_buku.setMinimumSize(new java.awt.Dimension(128, 24));
        tf_keyword_buku.setPreferredSize(new java.awt.Dimension(128, 24));

        tabel_buku.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        tabel_buku.setForeground(new java.awt.Color(47, 61, 99));
        tabel_buku.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Kode Buku", "Judul", "Penerbit", "Harga", "Stok"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tabel_buku.setGridColor(new java.awt.Color(204, 204, 204));
        tabel_buku.setRowHeight(24);
        tabel_buku.setRowMargin(2);
        tabel_buku.setSelectionBackground(new java.awt.Color(242, 255, 252));
        tabel_buku.setSelectionForeground(new java.awt.Color(47, 61, 99));
        tabel_buku.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(tabel_buku);

        javax.swing.GroupLayout panelMasterBukuLayout = new javax.swing.GroupLayout(panelMasterBuku);
        panelMasterBuku.setLayout(panelMasterBukuLayout);
        panelMasterBukuLayout.setHorizontalGroup(
            panelMasterBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMasterBukuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelMasterBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelMasterBukuLayout.createSequentialGroup()
                        .addComponent(btn_tambah_buku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(tf_keyword_buku, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_cari_buku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelMasterBukuLayout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 680, Short.MAX_VALUE))
                .addContainerGap())
        );
        panelMasterBukuLayout.setVerticalGroup(
            panelMasterBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMasterBukuLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panelMasterBukuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_tambah_buku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_cari_buku, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tf_keyword_buku, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 488, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelContainer.add(panelMasterBuku, "panelMasterBuku");

        splitPaneHome.setRightComponent(panelContainer);

        javax.swing.GroupLayout panelBackgroundLayout = new javax.swing.GroupLayout(panelBackground);
        panelBackground.setLayout(panelBackgroundLayout);
        panelBackgroundLayout.setHorizontalGroup(
            panelBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(splitPaneHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panelBackgroundLayout.setVerticalGroup(
            panelBackgroundLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(splitPaneHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBackground, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBackground, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_tambah_bukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambah_bukuActionPerformed
        // TODO add your handling code here:
        dialogTambahBuku.setVisible(true);
        dialogTambahBuku.setLocationRelativeTo(this);
    }//GEN-LAST:event_btn_tambah_bukuActionPerformed

    private void btn_cari_bukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cari_bukuActionPerformed
        String keyword = tf_keyword_buku.getText();
        cariBuku(keyword);
    }//GEN-LAST:event_btn_cari_bukuActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomeFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSidebarHome;
    private javax.swing.JButton btnSidebarMasterBuku;
    private javax.swing.JButton btn_cari_buku;
    private javax.swing.JButton btn_show_modal;
    private javax.swing.JButton btn_tambah;
    private javax.swing.JButton btn_tambah_buku;
    private javax.swing.JComboBox<String> cb_kategori;
    private javax.swing.JComboBox<String> cb_penerbit;
    private javax.swing.JDialog dialogTambahBuku;
    private javax.swing.JDialog dialogTest;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel label_jumlah_buku;
    private javax.swing.JPanel panelBackground;
    private javax.swing.JPanel panelContainer;
    private javax.swing.JPanel panelHome;
    private javax.swing.JPanel panelMasterBuku;
    private javax.swing.JPanel panelSidebar;
    private javax.swing.JSplitPane splitPaneHome;
    private javax.swing.JTable tabel_buku;
    private javax.swing.JTextField tf_harga;
    private javax.swing.JTextField tf_judul;
    private javax.swing.JTextField tf_keyword_buku;
    private javax.swing.JTextField tf_kode_buku;
    private javax.swing.JTextField tf_penulis;
    private javax.swing.JTextField tf_stok;
    private javax.swing.JTextField tf_tahun;
    // End of variables declaration//GEN-END:variables
}
